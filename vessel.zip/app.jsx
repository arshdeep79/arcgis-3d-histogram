import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Map, NavigationControl, Popup, useControl } from 'react-map-gl/maplibre';
import { GeoJsonLayer, ArcLayer, HexagonLayer, ColumnLayer, ScenegraphLayer } from 'deck.gl';
import { MapboxOverlay as DeckOverlay } from '@deck.gl/mapbox';

import 'maplibre-gl/dist/maplibre-gl.css';

// source: Natural Earth http://www.naturalearthdata.com/ via geojson.xyz
const AIR_PORTS =
  'https://d2ad6b4ur7yvpq.cloudfront.net/naturalearth-3.3.0/ne_10m_airports.geojson';

const INITIAL_VIEW_STATE = {
  latitude: 24.509399020184386,
  longitude: 54.3619504521851,
  zoom: 13,
  bearing: 0,
  pitch: 90
};

const MAP_STYLE = 'https://basemaps.cartocdn.com/gl/positron-gl-style/style.json';
function DeckGLOverlay(props) {
  const overlay = useControl(() => new DeckOverlay(props));
  overlay.setProps(props);
  return null;
}


const data = []
const generateSampleData = (numPoints = 100) => {
  const data = [];
  const centerLongitude = -0.4631566;
  const centerLatitude = 51.4939959;

  for (let i = 0; i < numPoints; i++) {
    const longitude = centerLongitude + (Math.random() - 0.5) * 0.1;
    const latitude = centerLatitude + (Math.random() - 0.5) * 0.1;
    const value = Math.random() * 100;
    data.push({ longitude, latitude, value });
  }

  return data;
};


function Root() {
  const [selected, setSelected] = useState(null);

  const layers = [

    new ScenegraphLayer({
      id: 'ScenegraphLayer',
      data: [{
        "coordinates": [INITIAL_VIEW_STATE.longitude, INITIAL_VIEW_STATE.latitude],

      }, {

        "coordinates": [54.346774631305586, 24.491339597085307],
      },
      {

        "coordinates": [54.34125259648608, 24.51525301860128],
      }
      ],
      getPosition: d => d.coordinates,
      getOrientation: d => [0, Math.random() * 360, 90],
      scenegraph: './file-1571061509915.glb',
      sizeScale: 500,
      _animations: {
        '*': { speed: 5 }
      },
      _lighting: 'pbr',
      pickable: true
    })
  ];

  return (
    <Map initialViewState={INITIAL_VIEW_STATE} mapStyle={MAP_STYLE}>
      {selected && (
        <Popup
          key={selected.properties.name}
          anchor="bottom"
          style={{ zIndex: 10 }} /* position above deck.gl canvas */
          longitude={selected.geometry.coordinates[0]}
          latitude={selected.geometry.coordinates[1]}
        >
          {selected.properties.name} ({selected.properties.abbrev})
        </Popup>
      )}
      <DeckGLOverlay layers={layers} /* interleaved*/ />
      <NavigationControl position="top-left" />
    </Map>
  );
}

/* global document */
const container = document.body.appendChild(document.createElement('div'));
createRoot(container).render(<Root />);
